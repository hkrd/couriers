## Couriers Challenge
run with ```uvicorn src.main:app  --reload```
run tests with ```poetry run pytest```