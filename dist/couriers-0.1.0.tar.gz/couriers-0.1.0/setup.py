# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['src']

package_data = \
{'': ['*']}

install_requires = \
['fastapi>=0.109.0,<0.110.0',
 'pydantic>=2.5.3,<3.0.0',
 'uvicorn>=0.25.0,<0.26.0']

setup_kwargs = {
    'name': 'couriers',
    'version': '0.1.0',
    'description': 'Couriers Challenge',
    'long_description': '## Couriers Challenge\nrun with ```uvicorn src.main:app  --reload```\nrun tests with ```poetry run pytest```',
    'author': 'Christian Radev',
    'author_email': 'sghradev@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
